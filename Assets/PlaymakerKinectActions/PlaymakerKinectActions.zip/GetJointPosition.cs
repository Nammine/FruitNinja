﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;
using System;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Kinect Actions")]
	[Tooltip("Allows you to get a user's joint position from the Kinect.")]
	
	public class GetJointPosition : FsmStateAction
	{
		public enum JointType : int
		{
			HipCenter = 0,
			Spine,
			ShoulderCenter,
			Head,
			ShoulderLeft,
			ElbowLeft,
			WristLeft,
			HandLeft,
			ShoulderRight,
			ElbowRight,
			WristRight,
			HandRight,
			HipLeft,
			KneeLeft,
			AnkleLeft,
			FootLeft,
			HipRight,
			KneeRight,
			AnkleRight,
			FootRight
		}
		
		// Setup to use the enum udpate
		[RequiredField]
		[Tooltip("Which joint you want to track.")]
		public JointType kinectJoint;
		
		// store the name of the gesture called
		[UIHint(UIHint.Variable)]
		[Tooltip("Store the position of the joint selected.")]
		public FsmVector3 jointPosition;
		
		private KinectManager manager;
		private int kinectJointIndex;
		
		
		// called when the state becomes active
		public override void OnEnter()
		{			
			kinectJointIndex = (int)kinectJoint;
			getKinectJointPos();
		}
		
		// called before leaving the current state
		public override void OnExit ()
		{
		}
		
		public override void OnUpdate()
		{
			//if (updateCall == PlayMakerUpdateCallType.Update)
			{
				getKinectJointPos();			
			}
		}
		
		// Update is called once per frame
		private void getKinectJointPos()
		{		
			if(manager == null)
			{
				manager = KinectManager.Instance;
			}
			
			if(manager != null && KinectManager.IsKinectInitialized() && manager.GetPrimaryUserID() > 0)
			{
				long userId = manager.GetPrimaryUserID();
				jointPosition.Value = manager.GetJointPosition(userId, kinectJointIndex);
			}
		}
	}
}